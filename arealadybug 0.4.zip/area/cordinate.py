# this is ladybug first settings
import os
import re
from qgis.core import (
    QgsProject, QgsVectorLayer, QgsCoordinateReferenceSystem,
    QgsMarkerSymbol, QgsPalLayerSettings, QgsTextFormat,
    QgsVectorLayerSimpleLabeling, QgsDataProvider, QgsMapLayer,
    QgsProviderRegistry, QgsField
)
from qgis.PyQt.QtCore import QVariant
from qgis.PyQt.QtGui import QColor, QFont
from qgis.utils import iface
from qgis.PyQt.QtWidgets import QMessageBox, QFileDialog, QInputDialog
from .Area_dialog import AreaDialog
from .ladybug_layer_properties import setup_ladybug_layer_properties

def is_valid_ladybug_format(file_path):
    """
    Check if the file has the correct ladybug format for coordinates
    Accept various formats that might be valid:
    - CSV format with numeric coordinates
    - Space or tab-delimited formats
    - File with at least some valid coordinate pairs
    """
    try:
        valid_lines = 0
        total_lines = 0
        
        with open(file_path, 'r') as f:
            lines = [line.strip() for line in f.readlines() if line.strip()]
            if not lines:
                return False
            
            total_lines = len(lines)
            
            # Try multiple delimiters (comma, tab, space)
            for line in lines[:10]:  # Check first 10 lines at most
                # Try comma-separated format first (most common)
                parts = line.split(',')
                if len(parts) >= 3:
                    try:
                        # Check if parts 1 and 2 (index 1,2) can be converted to float
                        x = float(parts[1].strip())
                        y = float(parts[2].strip())
                        valid_lines += 1
                        continue
                    except ValueError:
                        pass
                
                # Try space-separated format
                parts = line.split()
                if len(parts) >= 3:
                    try:
                        # Check if parts contain numeric values that could be coordinates
                        x = float(parts[1].strip())
                        y = float(parts[2].strip())
                        valid_lines += 1
                        continue
                    except ValueError:
                        pass
                
                # Try to find any numeric pairs in the line using regex
                coords = re.findall(r'[-+]?\d*\.\d+|[-+]?\d+', line)
                if len(coords) >= 2:
                    try:
                        x = float(coords[0])
                        y = float(coords[1])
                        valid_lines += 1
                        continue
                    except ValueError:
                        pass
            
            # If at least 30% of the lines examined are valid, consider it a valid format
            threshold = min(10, total_lines) * 0.3
            return valid_lines >= threshold
            
    except Exception as e:
        print(f"Error validating file {file_path}: {str(e)}")
        return False

def find_ladybug_files(folder_path):
    """
    Scan folder recursively for ladybug.txt or any txt files with ladybug coordinate format
    Returns files by folder priority
    """
    ladybug_files = []
    
    # scanner
    # First priority: look for files named exactly ladybug.txt
    for root, _, files in os.walk(folder_path):
        for file in files:
            if file.lower() == 'ladybug.txt':
                file_path = os.path.join(root, file)
                # Verify it has the correct format
                if is_valid_ladybug_format(file_path):
                    ladybug_files.append(file_path)
                    print(f"Found ladybug.txt: {file_path}")
    
    # If found any ladybug.txt files, return them
    if ladybug_files:
        return ladybug_files
    
    # Second priority: look for files with valid ladybug format
    for root, _, files in os.walk(folder_path):
        for file in files:
            if file.lower().endswith('.txt') and file.lower() != 'ladybug.txt':
                file_path = os.path.join(root, file)
                if is_valid_ladybug_format(file_path):
                    ladybug_files.append(file_path)
                    print(f"Found valid ladybug format file: {file_path}")
    
    return ladybug_files

def load_ladybug_file_automatically(file_path):
    """
    Open the file as a delimited text layer using QgsProviderRegistry
    """
    layer_name = os.path.splitext(os.path.basename(file_path))[0]
    
    # Create a QgsVectorLayer
    uri = f"file:///{file_path}?delimiter=,&crs=EPSG:32632&xField=field_2&yField=field_3"
    layer = QgsVectorLayer(uri, layer_name, "delimitedtext")

    # Check if the layer was created successfully
    if layer is None:
        QMessageBox.warning(
            iface.mainWindow(),
            "Layer Creation Error",
            f"Could not create layer {layer_name}."
        )
        return None
    
    if not layer.isValid():
        QMessageBox.warning(
            iface.mainWindow(),
            "Layer is Invalid",
            f"The layer created from {file_path} is not valid. Please check the file."
        )
        return None
    
    # Add layer to the project
    QgsProject.instance().addMapLayer(layer)
    
    # Set up layer properties (styling and labeling)
    setup_ladybug_layer_properties(layer)
    
    layer.triggerRepaint()
    iface.mapCanvas().refresh()
    iface.zoomToActiveLayer()
    
    return layer

def main():
    """
    Main function that automatically processes the ladybug file 
    """
    folder_path = QFileDialog.getExistingDirectory(
        iface.mainWindow(),
        "Select folder containing ladybug.txt",
        os.path.join(os.path.expanduser("~"), "Documents")
    )
    
    if not folder_path:
        print("No folder selected. Cancelling operation.")
        return
    
    ladybug_files = find_ladybug_files(folder_path)
    
    if not ladybug_files:
        QMessageBox.warning(
            iface.mainWindow(),
            "No Ladybug Files Found",
            f"No ladybug.txt or valid coordinate files found in {folder_path} or its subfolders."
        )
        return
    
    ladybug_file = ladybug_files[0]
    if len(ladybug_files) > 1:
        file_names = [os.path.basename(f) for f in ladybug_files]
        selected, ok = QInputDialog.getItem(
            iface.mainWindow(),
            "Select Ladybug File",
            "Multiple ladybug files found. Select one:",
            file_names,
            0,
            False
        )
        if ok and selected:
            index = file_names.index(selected)
            ladybug_file = ladybug_files[index]
        else:
            print("No file selected.")
            return
    
    ladybug_layer = load_ladybug_file_automatically(ladybug_file)
    
    if ladybug_layer:
        QMessageBox.information(
            iface.mainWindow(),
            "Success",
            f"Ladybug coordinates from {os.path.basename(ladybug_file)} loaded successfully with:\n"
            "- Styling applied\n"
            "- Filter configured\n"
            "- Labels set up"
        )

if __name__ == "__main__":
    main()
