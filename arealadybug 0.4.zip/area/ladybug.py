# This file is intentionally left blank.
# It is required to prevent a ModuleNotFoundError in area_plugin.py.
import os
import re
from qgis.core import (
    QgsProject, QgsVectorLayer, QgsCoordinateReferenceSystem,
    QgsMarkerSymbol, QgsPalLayerSettings, QgsTextFormat,
    QgsVectorLayerSimpleLabeling, QgsDataProvider, QgsMapLayer,
    QgsProviderRegistry, QgsField
)
from qgis.PyQt.QtCore import QVariant
from qgis.PyQt.QtGui import QColor, QFont
from qgis.utils import iface
from qgis.PyQt.QtWidgets import QMessageBox, QFileDialog, QInputDialog
from .Area_dialog import AreaDialog
from .ladybug_layer_properties import setup_ladybug_layer_properties