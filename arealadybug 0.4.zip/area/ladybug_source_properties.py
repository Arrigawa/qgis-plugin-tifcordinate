# all in one click here
# This function will process all TIF and ladybug files in a selected folder with one click.
import os
from qgis.PyQt.QtWidgets import QFileDialog, QMessageBox, QInputDialog
from qgis.utils import iface
from .TIF_taker import load_raster_layer
from .cordinate import is_valid_ladybug_format, setup_ladybug_layer_properties
from qgis.core import QgsProject, QgsVectorLayer

def all_in_one_click():
    folder_path = QFileDialog.getExistingDirectory(
        iface.mainWindow(),
        "Select folder containing TIF and ladybug files",
        os.path.join(os.path.expanduser("~"), "Documents")
    )
    if not folder_path:
        print("No folder selected. Cancelling operation.")
        return

    # --- TIF files ---
    tif_files = []
    for root, _, files in os.walk(folder_path):
        for file in files:
            if file.lower().endswith((".tif", ".tiff")):
                tif_files.append(os.path.join(root, file))
    loaded_rasters = []
    for tif_path in tif_files:
        raster_layer = load_raster_layer(tif_path)
        if raster_layer:
            loaded_rasters.append(raster_layer)

    # --- Ladybug files ---
    ladybug_files = []
    for root, _, files in os.walk(folder_path):
        for file in files:
            if file.lower() == "ladybug.txt":
                file_path = os.path.join(root, file)
                if is_valid_ladybug_format(file_path):
                    ladybug_files.append(file_path)
    if not ladybug_files:
        for root, _, files in os.walk(folder_path):
            for file in files:
                if file.lower().endswith('.txt') and file.lower() != 'ladybug.txt':
                    file_path = os.path.join(root, file)
                    if is_valid_ladybug_format(file_path):
                        ladybug_files.append(file_path)
    loaded_ladybugs = []
    for ladybug_file in ladybug_files:
        layer_name = os.path.splitext(os.path.basename(ladybug_file))[0]
        uri = f"file:///{ladybug_file}?delimiter=,&crs=EPSG:32632&xField=field_2&yField=field_3"
        layer = QgsVectorLayer(uri, layer_name, "delimitedtext")
        if layer and layer.isValid():
            QgsProject.instance().addMapLayer(layer)
            setup_ladybug_layer_properties(layer)
            layer.triggerRepaint()
            loaded_ladybugs.append(layer)
    # --- Notify user ---
    msg = f"Loaded {len(loaded_rasters)} TIF files and {len(loaded_ladybugs)} ladybug files."
    QMessageBox.information(
        iface.mainWindow(),
        "All in One Click",
        msg
    )
    iface.mapCanvas().refresh()
    if loaded_rasters or loaded_ladybugs:
        iface.mapCanvas().zoomToFullExtent()