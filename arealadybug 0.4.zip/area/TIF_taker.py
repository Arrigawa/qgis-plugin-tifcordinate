import os
from qgis.core import (
    QgsProject, QgsRasterLayer, 
    QgsApplication
)
from qgis.PyQt.QtGui import QColor
from qgis.utils import iface

def load_raster_layer(raster_path):
    """
    Load raster layer from specified path
    """
    if not os.path.exists(raster_path):
        print(f"Error: The raster file {raster_path} does not exist.")
        return None
    
    layer_name = os.path.basename(raster_path).split('.')[0]
    raster_layer = QgsRasterLayer(raster_path, layer_name)
    
    if not raster_layer.isValid():
        print(f"Error: Layer {raster_path} is invalid.")
        return None
    
    QgsProject.instance().addMapLayer(raster_layer)
    print(f"Raster layer '{layer_name}' loaded successfully.")
    return raster_layer

def main():
    from qgis.PyQt.QtWidgets import QFileDialog, QMessageBox
    
    # Ask user to select a folder to scan for TIF files
    folder_path = QFileDialog.getExistingDirectory(
        iface.mainWindow(),
        "Select folder to scan for TIF files",
        os.path.join(os.path.expanduser("~"), "Documents")
    )
    
    if not folder_path:
        print("No folder selected. Canceling operation.")
        return
    
    # Recursively scan folder and all subfolders for TIF files
    tif_files = []
    for root, _, files in os.walk(folder_path):
        for file in files:
            if file.lower().endswith(('.tif', '.tiff')):
                tif_files.append(os.path.join(root, file))
    
    if not tif_files:
        QMessageBox.warning(
            iface.mainWindow(), 
            "No TIF Files Found", 
            f"No TIF files were found in the selected folder or its subfolders: {folder_path}"
        )
        print("No TIF files found in the selected folder or its subfolders.")
        return
    
    # Display found TIF files
    print(f"Found {len(tif_files)} TIF files in {folder_path} and its subfolders:")
    for tif in tif_files:
        print(f" - {tif}")  # Show full path since files may be in different subfolders
    
    # Load all TIF files as raster layers
    loaded_layers = []
    for tif_path in tif_files:
        raster_layer = load_raster_layer(tif_path)
        if raster_layer:
            loaded_layers.append(raster_layer)
    
    # Refresh map canvas to show changes
    if loaded_layers:
        # Zoom to the extent of all loaded layers
        canvas = iface.mapCanvas()
        canvas.zoomToFullExtent()
        canvas.refresh()
        
        print("Process completed successfully.")
        
        QMessageBox.information(
            iface.mainWindow(),
            "Success",
            f"Loaded {len(loaded_layers)} TIF files successfully."
        )
    else:
        print("No layers were loaded successfully.")
        QMessageBox.warning(
            iface.mainWindow(),
            "Warning",
            "No layers were loaded successfully."
        )

if __name__ == "__main__":
    main()
