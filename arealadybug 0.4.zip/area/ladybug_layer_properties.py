from qgis.core import (
    QgsMarkerSymbol, QgsPalLayerSettings, QgsTextFormat,
    QgsVectorLayerSimpleLabeling
)
from qgis.PyQt.QtGui import QColor, QFont

def setup_ladybug_layer_properties(layer):
    """
    Sets up the styling, labeling, and provider filter properties for a ladybug layer.
    """
    # Apply styling - red circle markers
    symbol = QgsMarkerSymbol.createSimple({
        'name': 'circle', 
        'color': '255,0,0', 
        'stroke': '0,0,0',
        'size': '2',
        'outline_style': 'no'
    })
    layer.renderer().setSymbol(symbol)
    
    # Set up labels with correct field name
    label_settings = QgsPalLayerSettings()
    text_format = QgsTextFormat()
    text_format.setFont(QFont("Arial", 10))
    text_format.setColor(QColor(0, 0, 0))
    label_settings.setFormat(text_format)
    
    # Automatically find the field starting with "abc"
    abc_field_name = None
    abc_field_value = None
    features = layer.getFeatures()
    first_feature = next(features, None)
    
    for field in layer.fields():
        if field.name().startswith("abc"):
            abc_field_name = field.name()
            if first_feature:
                abc_field_value = first_feature[abc_field_name]
            break
    
    if abc_field_name:
        label_settings.fieldName = abc_field_name
        # Set the provider filter if we have both field name and value
        if abc_field_value:
            filter_expr = f"\"{abc_field_name}\" = '{abc_field_value}'"
            layer.setSubsetString(filter_expr)
    else:
        label_settings.fieldName = "Photo ID"
    
    label_settings.enabled = True
    layer.setLabeling(QgsVectorLayerSimpleLabeling(label_settings))
    layer.setLabelsEnabled(True)
    
    layer.triggerRepaint()
